import { useState, useMemo, useCallback } from 'react';
import type { PaletteColor, BrandName } from '../../types';
import type { ColorReplaceState } from '../../types/editTools';

interface ColorPickerProps {
  palette: PaletteColor[]; // 完整调色板
  selectedColor: PaletteColor | null;
  onColorSelect: (color: PaletteColor) => void;
  brand: BrandName;
  colorReplaceState?: ColorReplaceState;
  onColorReplace?: (sourceColor: PaletteColor, targetColor: PaletteColor) => void;
  currentColors?: PaletteColor[]; // 当前图像中使用的颜色
}

export default function ColorPicker({
  palette,
  selectedColor,
  onColorSelect,
  brand,
  colorReplaceState,
  onColorReplace,
  currentColors = [],
}: ColorPickerProps) {
  const [showFullPalette, setShowFullPalette] = useState(false);
  const [hoveredColor, setHoveredColor] = useState<string | null>(null);

  // 处理颜色选择
  const handleColorClick = useCallback((color: PaletteColor) => {
    // 如果处于颜色替换模式的第2步，执行颜色替换
    if (colorReplaceState?.isActive &&
        colorReplaceState.step === 'selectTarget' &&
        colorReplaceState.sourceColor &&
        onColorReplace) {
      onColorReplace(colorReplaceState.sourceColor, color);
    } else {
      // 正常颜色选择
      onColorSelect(color);
    }
  }, [colorReplaceState, onColorReplace, onColorSelect]);

  // 按色相分组聚集的排序算法
  const sortColorsByHSL = useCallback((colors: PaletteColor[]) => {
    const toHsl = (r: number, g: number, b: number) => {
      r /= 255;
      g /= 255;
      b /= 255;
      const max = Math.max(r, g, b);
      const min = Math.min(r, g, b);
      const l = (max + min) / 2;
      let h = 0;
      let s = 0;
      if (max !== min) {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
          case r:
            h = ((g - b) / d + (g < b ? 6 : 0)) * 60;
            break;
          case g:
            h = ((b - r) / d + 2) * 60;
            break;
          case b:
            h = ((r - g) / d + 4) * 60;
            break;
        }
      }
      return { h, s, l };
    };

    return [...colors].sort((a, b) => {
      const hslA = toHsl(a.rgb.r, a.rgb.g, a.rgb.b);
      const hslB = toHsl(b.rgb.r, b.rgb.g, b.rgb.b);
      const isGrayA = hslA.s < 0.08;
      const isGrayB = hslB.s < 0.08;

      // 无彩色（黑白灰）排最前面，按亮度从暗到亮
      if (isGrayA && isGrayB) return hslA.l - hslB.l;
      if (isGrayA) return -1;
      if (isGrayB) return 1;

      // 彩色按色相每30°分一组（共12组）
      const bucketA = Math.floor(hslA.h / 30);
      const bucketB = Math.floor(hslB.h / 30);
      if (bucketA !== bucketB) return bucketA - bucketB;

      // 同组内按亮度从亮到暗排列
      return hslB.l - hslA.l;
    });
  }, []);

  // 显示的颜色列表（不过滤，所有品牌颜色集合相同）
  const displayColors = useMemo(() => {
    const colors = showFullPalette ? palette : currentColors;
    return sortColorsByHSL(colors);
  }, [showFullPalette, palette, currentColors, sortColorsByHSL]);

  return (
    <div className="bg-white rounded-2xl shadow-lg p-3">
      {/* Tab 切换按钮 - 两个标签页 */}
      {currentColors.length > 0 && (
        <div className="flex gap-1 mb-3">
          {/* 当前色板 Tab */}
          <button
            onClick={() => setShowFullPalette(false)}
            className={`flex-1 py-2 px-3 text-[13px] font-medium rounded-md transition-colors ${
              !showFullPalette
                ? 'bg-[#3b82f6] text-white'
                : 'bg-transparent text-[#9ca3af] hover:bg-white/10'
            }`}
          >
            当前色板 ({currentColors.length}色)
          </button>

          {/* 完整色板 Tab */}
          <button
            onClick={() => setShowFullPalette(true)}
            className={`flex-1 py-2 px-3 text-[13px] font-medium rounded-md transition-colors ${
              showFullPalette
                ? 'bg-[#3b82f6] text-white'
                : 'bg-transparent text-[#9ca3af] hover:bg-white/10'
            }`}
          >
            完整色板 ({palette.length}色)
          </button>
        </div>
      )}

      {/* 颜色网格 - 优化性能的自适应布局 */}
      <div
        className="overflow-y-auto mb-3 scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100"
        style={{ maxHeight: '280px' }}
      >
        <div
          className="grid"
          style={{
            gridTemplateColumns: 'repeat(auto-fill, minmax(36px, 1fr))',
            gap: '2px',
            width: '100%'
          }}
        >
          {displayColors.map((color) => {
            const isSelected = selectedColor?.hex === color.hex;
            const isSourceColor = colorReplaceState?.sourceColor?.hex === color.hex;
            const isHovered = hoveredColor === color.hex;

            return (
              <button
                key={color.hex}
                onClick={() => handleColorClick(color)}
                onMouseEnter={() => setHoveredColor(color.hex)}
                onMouseLeave={() => setHoveredColor(null)}
                className={`
                  relative w-9 h-9 rounded-md transition-all cursor-pointer
                  ${isSelected ? 'ring-2 ring-[#3b82f6] ring-offset-1 scale-110' : ''}
                  ${isSourceColor ? 'ring-2 ring-amber-400 ring-offset-1' : ''}
                  ${!isSelected && !isSourceColor ? 'hover:scale-105 hover:shadow-md' : ''}
                `}
                style={{
                  backgroundColor: color.hex,
                  border: '1px solid rgba(0,0,0,0.1)',
                  transition: 'transform',
                }}
                title={`${color.codes[brand] || '未知'} - ${color.hex}`}
              >
                {/* 悬停时显示色号 */}
                {isHovered && (
                  <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-gray-800 text-white text-xs px-2 py-1 rounded whitespace-nowrap z-10">
                    {color.codes[brand] || '未知'}
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* 当前选中颜色信息 */}
      {selectedColor && (
        <div className="p-2 bg-gray-50 rounded-lg">
          <div className="flex items-center gap-2 text-xs">
            <div
              className="w-4 h-4 rounded border border-gray-300 flex-shrink-0"
              style={{ backgroundColor: selectedColor.hex }}
            />
            <span className="text-gray-700 font-medium truncate">
              当前: {selectedColor.codes[brand] || '未知色号'}
            </span>
          </div>
        </div>
      )}

      {/* 空状态提示 */}
      {displayColors.length === 0 && (
        <div className="text-sm text-gray-500 text-center py-6">
          {showFullPalette ? '没有可用颜色' : '图像中未使用任何颜色'}
        </div>
      )}
    </div>
  );
}
