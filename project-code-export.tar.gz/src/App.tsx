import { useState, useMemo, useCallback, useRef } from 'react';
import type { ImageState, ConfigState, BrandName, MappedPixel } from './types';
import { loadPalette } from './core/colorUtils';
import { calculatePixelGrid, calculateGridSize } from './core/pixelation';
import { calculateColorStats } from './utils/colorStats';
import { exportPatternImage } from './utils/export';
import { mergeColors } from './utils/colorMerge';
import { markExternalCells } from './utils/backgroundRemoval';
import { removeNoiseColors } from './utils/noiseRemoval';
import { autoRemoveNoiseColors } from './utils/autoNoiseRemoval';
import { replaceColor } from './utils/pixelEdit';
import { useManualEdit } from './hooks/useManualEdit';
import UploadArea from './components/ImageUpload/UploadArea';
import EditableCanvas from './components/EditTools/EditableCanvas';
import ControlPanel from './components/Controls/ControlPanel';
import ColorStats from './components/Stats/ColorStats';
import Toolbar from './components/EditTools/Toolbar';
import ColorPicker from './components/EditTools/ColorPicker';
import NoiseRemoval from './components/Controls/NoiseRemoval';
import type { PaletteColor } from './types';

function App() {
  const [imageState, setImageState] = useState<ImageState>({
    originalImage: null,
    processedGrid: null,
    dimensions: { N: 0, M: 0 },
  });

  const [configState, setConfigState] = useState<ConfigState>({
    gridSize: 50,
    mode: 'average',
    brand: 'MARD',
    mergeThreshold: 0,
  });

  const [tempGridSize, setTempGridSize] = useState(50);
  const [tempMergeThreshold, setTempMergeThreshold] = useState(0);
  const [removeBackground, setRemoveBackground] = useState(false);
  const [excludedColors, setExcludedColors] = useState<Set<string>>(new Set());

  const [isProcessing, setIsProcessing] = useState(false);
  const [rawGrid, setRawGrid] = useState<any>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [autoNoiseRemovalApplied, setAutoNoiseRemovalApplied] = useState(false);
  const [removedColorsCount, setRemovedColorsCount] = useState(0);
  const [gridBeforeAutoNoise, setGridBeforeAutoNoise] = useState<any>(null);

  const editState = useManualEdit(imageState.processedGrid);
  const palette = useMemo(() => loadPalette(), []);

  const handleImageLoad = useCallback((img: HTMLImageElement) => {
    const canvas = document.createElement('canvas');
    canvas.width = img.width;
    canvas.height = img.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(img, 0, 0);
    const { N, M } = calculateGridSize(img.width, img.height, configState.gridSize);

    setImageState({
      originalImage: img,
      processedGrid: null,
      dimensions: { N, M },
    });

    canvasRef.current = canvas;
    processImage(canvas, N, M);
  }, [configState.gridSize]);

  const processImage = useCallback(
    (canvas: HTMLCanvasElement, N: number, M: number) => {
      setIsProcessing(true);

      setTimeout(() => {
        try {
          let grid = calculatePixelGrid(canvas, N, M, palette, 'average');
          setRawGrid(grid);

          grid = mergeColors(grid, configState.mergeThreshold);

          if (excludedColors.size > 0) {
            grid = removeNoiseColors(grid, excludedColors, palette);
          }

          setImageState((prev) => ({
            ...prev,
            processedGrid: grid,
            dimensions: { N, M },
          }));
        } catch (error) {
          console.error('处理图像失败:', error);
          alert('处理图像失败，请重试');
        } finally {
          setIsProcessing(false);
        }
      }, 100);
    },
    [palette, configState.mergeThreshold, excludedColors]
  );

  const handleGridSizeChange = useCallback((size: number) => {
    setTempGridSize(size);
  }, []);

  const handleMergeThresholdChange = useCallback((threshold: number) => {
    setTempMergeThreshold(threshold);
  }, []);

  const handleApplyParameters = useCallback(() => {
    const clampedGridSize = Math.max(10, Math.min(300, tempGridSize || 50));
    const clampedMergeThreshold = Math.max(0, Math.min(100, tempMergeThreshold || 0));

    setTempGridSize(clampedGridSize);
    setTempMergeThreshold(clampedMergeThreshold);

    const gridSizeChanged = clampedGridSize !== configState.gridSize;
    const thresholdChanged = clampedMergeThreshold !== configState.mergeThreshold;

    if (!gridSizeChanged && !thresholdChanged) {
      return;
    }

    setConfigState((prev) => ({
      ...prev,
      gridSize: clampedGridSize,
      mergeThreshold: clampedMergeThreshold,
    }));

    if (gridSizeChanged && imageState.originalImage && canvasRef.current) {
      const { N, M } = calculateGridSize(
        imageState.originalImage.width,
        imageState.originalImage.height,
        clampedGridSize
      );
      processImage(canvasRef.current, N, M);
      setRemoveBackground(false);
    } else if (thresholdChanged && rawGrid) {
      setIsProcessing(true);
      setTimeout(() => {
        let grid = mergeColors(rawGrid, clampedMergeThreshold);

        if (excludedColors.size > 0) {
          grid = removeNoiseColors(grid, excludedColors, palette);
        }

        if (removeBackground) {
          grid = markExternalCells(grid);
        }

        setImageState((prev) => ({
          ...prev,
          processedGrid: grid,
        }));
        setIsProcessing(false);
      }, 100);
    }
  }, [tempGridSize, tempMergeThreshold, configState.gridSize, configState.mergeThreshold, imageState.originalImage, rawGrid, removeBackground, excludedColors, palette]);

  const handleBrandChange = useCallback((brand: BrandName) => {
    setConfigState((prev) => ({ ...prev, brand }));
  }, []);

  const handleRemoveBackgroundChange = useCallback((remove: boolean) => {
    if (!imageState.processedGrid) return;

    setRemoveBackground(remove);
    setIsProcessing(true);

    setTimeout(() => {
      let grid = imageState.processedGrid!;

      if (remove) {
        grid = markExternalCells(grid);
        const externalCount = grid.flat().filter(p => p.isExternal).length;
        const totalCount = grid.flat().length;
        console.log(`背景移除：${externalCount}/${totalCount} 个单元格被标记为外部背景`);
      } else {
        if (rawGrid) {
          grid = mergeColors(rawGrid, configState.mergeThreshold);

          if (excludedColors.size > 0) {
            grid = removeNoiseColors(grid, excludedColors, palette);
          }
        }
      }

      setImageState((prev) => ({
        ...prev,
        processedGrid: grid,
      }));
      setIsProcessing(false);
    }, 100);
  }, [imageState.processedGrid, rawGrid, configState.mergeThreshold, excludedColors, palette]);

  const colorStats = useMemo(() => {
    if (!imageState.processedGrid) return [];
    return calculateColorStats(imageState.processedGrid, configState.brand);
  }, [imageState.processedGrid, configState.brand]);

  const currentColors = useMemo(() => {
    if (!imageState.processedGrid) return [];

    const colorMap = new Map<string, PaletteColor>();

    for (const row of imageState.processedGrid) {
      for (const pixel of row) {
        if (!pixel.isExternal && !colorMap.has(pixel.paletteColor.hex)) {
          colorMap.set(pixel.paletteColor.hex, pixel.paletteColor);
        }
      }
    }

    return Array.from(colorMap.values());
  }, [imageState.processedGrid]);

  const handleColorExclude = useCallback((hex: string) => {
    setExcludedColors((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(hex)) {
        newSet.delete(hex);
        console.log(`恢复颜色: ${hex}`);
      } else {
        newSet.add(hex);
        console.log(`排除颜色: ${hex}`);
      }
      return newSet;
    });

    if (rawGrid) {
      setIsProcessing(true);
      setTimeout(() => {
        let grid = mergeColors(rawGrid, configState.mergeThreshold);

        const updatedExcludedColors = new Set(excludedColors);
        if (updatedExcludedColors.has(hex)) {
          updatedExcludedColors.delete(hex);
        } else {
          updatedExcludedColors.add(hex);
        }

        if (updatedExcludedColors.size > 0) {
          grid = removeNoiseColors(grid, updatedExcludedColors, palette);
        }

        if (removeBackground) {
          grid = markExternalCells(grid);
        }

        setImageState((prev) => ({
          ...prev,
          processedGrid: grid,
        }));
        setIsProcessing(false);
      }, 50);
    }
  }, [rawGrid, configState.mergeThreshold, excludedColors, removeBackground, palette]);

  const handleAutoNoiseRemoval = useCallback((thresholdPercent: number) => {
    if (!imageState.processedGrid) return;

    setIsProcessing(true);

    setTimeout(() => {
      setGridBeforeAutoNoise(imageState.processedGrid);

      const { newGrid, removedColors } = autoRemoveNoiseColors(
        imageState.processedGrid!,
        thresholdPercent,
        palette
      );

      setImageState((prev) => ({
        ...prev,
        processedGrid: newGrid,
      }));

      setAutoNoiseRemovalApplied(true);
      setRemovedColorsCount(removedColors.size);
      setIsProcessing(false);
    }, 50);
  }, [imageState.processedGrid, palette]);

  const handleRestoreAutoNoise = useCallback(() => {
    if (!gridBeforeAutoNoise) return;

    setImageState((prev) => ({
      ...prev,
      processedGrid: gridBeforeAutoNoise,
    }));

    setAutoNoiseRemovalApplied(false);
    setRemovedColorsCount(0);
    setGridBeforeAutoNoise(null);
  }, [gridBeforeAutoNoise]);

  const handleColorReplace = useCallback((sourceColor: PaletteColor, targetColor: PaletteColor) => {
    if (!editState.editGrid) return;

    const { newGrid, replaceCount } = replaceColor(
      editState.editGrid,
      sourceColor,
      targetColor
    );

    if (replaceCount > 0) {
      editState.applyEdit(newGrid);
      editState.completeColorReplace();
      console.log(`批量替换完成：替换了 ${replaceCount} 个像素`);
    } else {
      console.log('没有找到需要替换的颜色');
    }
  }, [editState]);

  const handleToggleEditMode = useCallback(() => {
    if (editState.isEditMode && editState.editGrid) {
      editState.setIsEditMode((finalGrid: MappedPixel[][]) => {
        setImageState(prev => ({
          ...prev,
          processedGrid: finalGrid
        }));
      });
    } else {
      editState.setIsEditMode();
    }
  }, [editState]);

  const handleExport = useCallback(() => {
    const gridToExport = editState.isEditMode && editState.editGrid
      ? editState.editGrid
      : imageState.processedGrid;

    if (!gridToExport) return;

    const statsToExport = calculateColorStats(gridToExport, configState.brand);
    exportPatternImage(gridToExport, configState.brand, statsToExport);
  }, [editState.isEditMode, editState.editGrid, imageState.processedGrid, configState.brand]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-blue-50 to-yellow-50">
      <div className="container mx-auto px-4 py-8">
        {/* 标题 */}
        <header className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            拼豆图纸生成工具
          </h1>
          <p className="text-gray-600">上传图片，一键生成拼豆图纸</p>
        </header>

        {/* 主内容区域 */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* 左侧：预览区域 */}
          <div className="lg:col-span-2 space-y-6">
            {!imageState.originalImage ? (
              <UploadArea onImageLoad={handleImageLoad} />
            ) : (
              <>
                {isProcessing && (
                  <div className="bg-yellow-100 border-2 border-yellow-400 rounded-2xl p-4 text-center">
                    <div className="text-yellow-800 font-semibold">
                      正在处理图片，请稍候...
                    </div>
                  </div>
                )}
                <EditableCanvas
                  grid={editState.isEditMode ? editState.editGrid : imageState.processedGrid}
                  brand={configState.brand}
                  isEditMode={editState.isEditMode}
                  currentTool={editState.currentTool}
                  selectedColor={editState.selectedColor}
                  onEdit={editState.applyEdit}
                  colorReplaceState={editState.colorReplaceState}
                  onSelectSourceColor={editState.selectSourceColor}
                />
                {imageState.processedGrid && (
                  <div className="flex gap-4">
                    <button
                      onClick={handleExport}
                      className="flex-1 bg-primary text-white py-3 px-6 rounded-xl font-semibold hover:bg-primary/90 transition-all shadow-lg hover:shadow-xl"
                    >
                      导出图纸
                    </button>
                    <button
                      onClick={() => window.location.reload()}
                      className="flex-1 bg-gray-200 text-gray-700 py-3 px-6 rounded-xl font-semibold hover:bg-gray-300 transition-all"
                    >
                      重新开始
                    </button>
                  </div>
                )}
              </>
            )}
          </div>

          {/* 右侧：控制面板和统计 */}
          <div className="space-y-6">
            {imageState.processedGrid && (
              <Toolbar
                currentTool={editState.currentTool}
                onToolChange={editState.setCurrentTool}
                canUndo={editState.canUndo}
                canRedo={editState.canRedo}
                onUndo={editState.undo}
                onRedo={editState.redo}
                isEditMode={editState.isEditMode}
                onToggleEditMode={handleToggleEditMode}
                colorReplaceState={editState.colorReplaceState}
                onToggleColorReplace={editState.toggleColorReplace}
              />
            )}

            {editState.isEditMode && imageState.processedGrid && (
              <ColorPicker
                palette={palette}
                selectedColor={editState.selectedColor}
                onColorSelect={editState.setSelectedColor}
                brand={configState.brand}
                colorReplaceState={editState.colorReplaceState}
                onColorReplace={handleColorReplace}
                currentColors={currentColors}
              />
            )}

            <ControlPanel
              gridSize={tempGridSize}
              onGridSizeChange={handleGridSizeChange}
              mergeThreshold={tempMergeThreshold}
              onMergeThresholdChange={handleMergeThresholdChange}
              removeBackground={removeBackground}
              onRemoveBackgroundChange={handleRemoveBackgroundChange}
              brand={configState.brand}
              onBrandChange={handleBrandChange}
              onApplyParameters={handleApplyParameters}
              disabled={!imageState.originalImage || isProcessing}
            />

            {imageState.processedGrid && (
              <NoiseRemoval
                onApply={handleAutoNoiseRemoval}
                onRestore={handleRestoreAutoNoise}
                disabled={isProcessing}
                hasApplied={autoNoiseRemovalApplied}
                removedColorsCount={removedColorsCount}
              />
            )}

            {colorStats.length > 0 && (
              <ColorStats
                stats={colorStats}
                removeBackground={removeBackground}
                excludedColors={excludedColors}
                onColorExclude={handleColorExclude}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
